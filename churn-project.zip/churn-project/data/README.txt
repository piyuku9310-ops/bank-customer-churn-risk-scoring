Put your dataset file here and name it churn.csv
Target column should be 'Churn' or 'churn'
